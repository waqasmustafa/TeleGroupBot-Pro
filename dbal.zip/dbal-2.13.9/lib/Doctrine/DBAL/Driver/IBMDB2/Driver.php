<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Driver\IBMDB2;

final class Driver extends DB2Driver
{
}
