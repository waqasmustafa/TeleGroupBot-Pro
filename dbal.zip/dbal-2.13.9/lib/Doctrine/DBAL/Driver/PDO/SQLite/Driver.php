<?php

namespace Doctrine\DBAL\Driver\PDO\SQLite;

use Doctrine\DBAL\Driver\PDOSqlite;

final class Driver extends PDOSqlite\Driver
{
}
